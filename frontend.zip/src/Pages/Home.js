/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";

const Home = () => {
  return <div>home</div>;
};

export default Home;
